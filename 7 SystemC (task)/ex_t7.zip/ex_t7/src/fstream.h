#define _CRT_SECURE_NO_WARNINGS
#define WIN32_LEAN_AND_MEAN

#include <iostream.h>
#include <fstream> //#include <fstream> <--> #include <iostream>// <--> ofstream

//using std::ofstream;
//using std::flush;
//using namespace std;

